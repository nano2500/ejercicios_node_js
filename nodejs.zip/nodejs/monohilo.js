console.log('Hola mundo');

let i = 0;


setInterval(function(){
    console.log(i); // este es el evento y en node es un ejemplo de asincronia ya que realiza el proceso cuando le toca.
    i++;
}, 1000); // cada cuanto va a ejecutar el evento

console.log('Segunda instruccion') 

