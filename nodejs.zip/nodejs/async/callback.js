 function hola(nombre, micallback){
     
    
    setTimeout(function (){
        console.log('hola' + nombre)
        micallback();
    },1000);
 
    }

function adios(nombre, otrocallback){
    setTimeout(function(){
        console.log( 'Terminando proceso', nombre);
        otrocallback();
    },1000);
}






 hola('luis', function(){
     adios('Gustavo', function(){
     console.log('Terminando proceso');
     });
 });