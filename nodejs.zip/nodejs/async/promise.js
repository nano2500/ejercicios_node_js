function hola(nombre){

    return new Promise(function(resolve, reject){
        setTimeout(function (){
            console.log('Hola ' + nombre)
            resolve();
        },1000);
     


    });
     
    
   
    }

function hablar(nombre){
    return new Promise (function(resolve, reject){
        setTimeout(function(){
            console.log('Como estas');
            resolve();
        },1000);

    })
    

    }

    function adios(nombre){

        return new Promise(function(resolve, reject){
            setTimeout(function (){
                console.log('adios', nombre)
                resolve();
            },1000);
         
    
    
        });
         
        
       
        }

    console.log('Inicio del proceso...');

    hola('Luis')
        .then(hablar)
        .then(adios)
    
        .then((nombre)=>{


            console.log('Terminado el proceso');

        })
        .catch(error =>{
            console.log('tenemos un error');
            console.error(error);
            

        })
        