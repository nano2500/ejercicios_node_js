function hola(nombre, micallback){
     
    
    setTimeout(function (){
        console.log('Hola ' + nombre)
        micallback();
    },1000);
 
    }

function hablar(callbackHablar){
    setTimeout(function(){
        console.log('Como estas');
        callbackHablar();
    },1000);

    }

function hablardespues(callbackHablarDespues){
    setTimeout(function(){
        console.log('Bien y tu?');
        callbackHablarDespues();
    },1000);
}

function hablardespuesde(callbackHablardespuesde){
    setTimeout(function(){
        console.log('Bien gracias');
        callbackHablardespuesde();
    },1000);
}

function adios(nombre, otrocallback){
    setTimeout(function(){
        console.log( 'Terminando proceso', nombre);
        otrocallback();
    },1000);
}

function conversacion(nombre, veces, callback){
    //recursividad  llamar  a la funcion con cosas minimamente distintas
    if(veces = 0){
    hablar(function(){
        conversacion(nombre, --veces, callback);

    })
 }else {
     adios(nombre,callback);
 }


}


hola('carlos', function(nombre){
    conversacion(nombre,3,function(){
        console.log('Proceso terminado');
    });
})






 //hola('Luis ', function(){
   //  hablar(function(){
     //    hablardespues(function(){
       //      hablardespuesde(function(){
         //       adios('Gustavo', function(){
           //         console.log('');
             //       });

             //});
            

        // });
        

     //});
     
 //});


