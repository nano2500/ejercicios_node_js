const fs  =require('fs');
const { Console } = require('console');


function leer(ruta, cb){
    fs.readFile(ruta, (err, data)=>{
        //se lee el documento
        cb(data.toString());
    })
}

function escribir(ruta,contenido,cb){
    fs.writeFile(ruta, contenido, function(err){
        if(err){
            console.error('No se ha podido escribir', err);

            
        }else{
            console.log('se escribio correctamente')
        }

    });
}

function borrar(ruta, cb){
    fs.unlink(ruta, cb);
}
borrar(__dirname+'archiv01.txt', console.log)
//escribir(__dirname + 'archiv01.txt', 'este es un nuevo archivo', console.log)

//leer(__dirname + '/archivo.txt',  console.log)