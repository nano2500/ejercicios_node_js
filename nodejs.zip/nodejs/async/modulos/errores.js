function otraFuncion(){
    return serompe();
}

function serompe(){
    return 3+z;
}

function serompeAsincrona(){
    setTimeout(function(cb){
        try{
            return 3+z;

        } catch(err){
            console.error(err.message);
            
        }
        

    })
}



try{
    //otraFuncion();
    serompeAsincrona(function(){
        console.log('error grave');
    });
} catch(err){
    console.error('Vaya ,algo salio mal');
}