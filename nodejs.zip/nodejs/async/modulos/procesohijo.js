const {exec,spawn} = require ('child_process');
const { stdout } = require('process');

//exec es para reptir procesos de sistemas como ejecutar scripts comando de sistemas etc

//exec('dir', (err, stdout, sterr)=>{
    //if(err){
       // console.error(err.message);
       // return false;
  //  }

   // console.log(stdout);
//})


//spawn invocar un proceso nuevo de node js

let proceso = spawn('dir');

console.log(proceso.pid);
console.log(proceso.connected);

proceso.stdout.on('data', function(dato){
    console.log(dato.toString())
})