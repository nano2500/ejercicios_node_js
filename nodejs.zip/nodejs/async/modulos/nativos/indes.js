const miAddon=require('addon');
console.l;og(miAddon)