process.on('beforeExit', ()=>{
    console.log('el proceso se va a  acabar');


});

process.on('exit', ()=>{
    console.log('el proceso se acabo');
    

});

process.on('uncaughtException',(err, origen)=>{
    console.error('vaya se nos ha olvidadp capturar el error');
    console.error(err);
});

