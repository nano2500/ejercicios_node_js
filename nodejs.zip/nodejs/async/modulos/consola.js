var tabla =[
    {
        a:1,
        b:'z',
    },

    {
        a:2,
        b:'otra letra',
    }
]

console.log('algo'); // muestra algo en consola
console.error('sirve para mostrar errores');
console.warn('sirve para mostrar advertencias');
console.table(tabla); // visualiza datos en forma de  tabla
console.group('Conversacion');
console.log('hola');
console.groupEnd('Conversacion');
console.count('veces');
console.count('veces');
console.count('veces');
console.count('veces');
console.countReset('veces');
console.count('veces');
console.count('veces');


function funcion1(){
    console.group('Primera funcion');
    console.log(1+1);
    console.groupEnd('primera funcion');
}

function funcion2(){
    console.group('segunda funcion');
    console.log(2+1);
    console.groupEnd('segunda funcion');
}


console.log('empezemos');
funcion1();
funcion2();





