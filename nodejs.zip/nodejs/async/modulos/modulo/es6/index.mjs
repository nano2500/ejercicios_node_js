import modulo from './modulo'

modulo();