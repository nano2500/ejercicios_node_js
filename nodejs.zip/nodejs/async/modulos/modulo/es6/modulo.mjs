function saludar(){
    console.log('hola mundo');
}

export default saludar;