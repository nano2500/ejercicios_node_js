//traer nuestro modulo
const modulo = require ('./modulo');

//ejecutar una funcion del modulo
console.log(modulo.prop1);
modulo.saludar();
//modulo();
