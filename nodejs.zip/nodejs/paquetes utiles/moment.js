const moment = require ('moment');

let ahora = moment();

//console.log(ahora);

console.log(ahora.dayOfYear(2019));
