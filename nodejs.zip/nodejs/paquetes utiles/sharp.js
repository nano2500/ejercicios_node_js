const sharp = require('sharp')

sharp('hola.png')
    .resize(80)
    .toFile('resized.png');