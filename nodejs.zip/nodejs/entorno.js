let nombre= process.env.NOMBRE || 'Sin nombre';
let web=process.env.WEB || 'Sin web';
console.log('Hola ' + nombre)
console.log('Mi web es ' + web)


//process.env.nombrevariable    esta es la forma de usar entorno de variable de entorno lo que trata es que que trae variables desde afuera y los usa en la aplicaciom
// crea el nombre del entorno de variable en mayuscula